﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityChatbot1
{
    internal class Program
    {
        static void PlayGreeting()
        {
            string filePath = "voice_greeting.wav"; // Relative path

            if (!System.IO.File.Exists(filePath))
            {
                Console.WriteLine("Error: Sound file not found at " + filePath);
                return;
            }

            try
            {
                SoundPlayer player = new SoundPlayer(filePath);
                player.PlaySync();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing sound: " + ex.Message);
            }
        }

        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Green; // Set color to green for cybersecurity theme
            Console.WriteLine(@"

   ______      __              _____                      _ __           ____        __ 
  / ____/_  __/ /_  ___  _____/ ___/___  _______  _______(_) /___  __   / __ )____  / /_
 / /   / / / / __ \/ _ \/ ___/\__ \/ _ \/ ___/ / / / ___/ / __/ / / /  / __  / __ \/ __/
/ /___/ /_/ / /_/ /  __/ /   ___/ /  __/ /__/ /_/ / /  / / /_/ /_/ /  / /_/ / /_/ / /_  
\____/\__, /_.___/\___/_/   /____/\___/\___/\__,_/_/  /_/\__/\__, /  /_____/\____/\__/  
     /____/                                                 /____/                      
");
            Console.ResetColor(); // Reset color to default
        }

        static string GetUserInput(string prompt)
        {
            string input;
            do
            {
                Console.Write(prompt);
                input = Console.ReadLine();
            } while (string.IsNullOrWhiteSpace(input));

            return input;
        }


        static void GreetUser()
        {
            string name = GetUserInput("Please enter your name: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nWelcome, {name}! I'm your Cybersecurity Awareness Bot.");
            Console.ResetColor();
        }

        static void Chat()
        {
            Console.WriteLine("\nYou can ask me about cybersecurity topics like:");
            Console.WriteLine("- Password safety");
            Console.WriteLine("- Phishing");
            Console.WriteLine("- Safe browsing");
            Console.WriteLine("Type 'exit' to quit.\n");

            while (true)
            {
                Console.Write("\nYou: ");
                string input = Console.ReadLine()?.ToLower();

                if (input == "exit")
                {
                    Console.WriteLine("Goodbye! Stay safe online.");
                    break;
                }
                else if (input.Contains("password"))
                {
                    Console.WriteLine("Use strong passwords with uppercase, lowercase, numbers, and symbols.");
                }
                else if (input.Contains("phishing"))
                {
                    Console.WriteLine("Don't click on suspicious links in emails or messages.");
                }
                else if (input.Contains("safe browsing"))
                {
                    Console.WriteLine("Always check website URLs before entering personal information.");
                }
                else
                {
                    Console.WriteLine("I didn't quite understand that. Could you rephrase?");
                }
            }
        }




        static void Main(string[] args)
        {
            PlayGreeting();
            DisplayAsciiArt();
            GreetUser();
            Chat();
        }
    }
}
